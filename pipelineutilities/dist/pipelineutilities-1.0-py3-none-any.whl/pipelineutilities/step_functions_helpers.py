import datetime
import boto3


def save_config(config, filename):
    ""


def get_config(filename):
    ""


def generate_config_filename():
    return str(datetime.datetime.now()) + ".json"
